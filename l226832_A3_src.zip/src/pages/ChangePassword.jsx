import React, { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { changePasswordUser } from '../redux/userSlice';

function ChangePassword() {
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');

  const dispatch = useDispatch();
  const navigate = useNavigate();

  const currentUser = useSelector((state) => state.user.currentUser);
  const isLoggedIn = useSelector((state) => state.user.isLoggedIn);

  const handleSubmit = (e) => {
    e.preventDefault();

    // Verify session and validate password matching logic
    if (!isLoggedIn) {
      alert("You must be logged in to change your password.");
      navigate('/login');
      return;
    }

    if (currentPassword !== currentUser.password) {
      alert("Your current password is incorrect!");
      return;
    }

    if (newPassword !== confirmPassword) {
      alert("Your new passwords do not match!");
      return;
    }

    dispatch(changePasswordUser(newPassword));
    alert("Password changed successfully!");
    
    // Reset state and redirect
    setCurrentPassword('');
    setNewPassword('');
    setConfirmPassword('');
    navigate('/rides');
  };

  return (
    <div className="container mt-5">
      <div className="row justify-content-center">
        <div className="col-md-6">
          <div className="card shadow-sm">
            <div className="card-body">
              <h3 className="card-title text-center mb-4">Change Password</h3>
              
              <form onSubmit={handleSubmit}>
                <div className="mb-3">
                  <label>Current Password</label>
                  <input 
                    type="password" 
                    className="form-control" 
                    value={currentPassword} 
                    onChange={(e) => setCurrentPassword(e.target.value)} 
                    required 
                  />
                </div>
                <div className="mb-3">
                  <label>New Password</label>
                  <input 
                    type="password" 
                    className="form-control" 
                    value={newPassword} 
                    onChange={(e) => setNewPassword(e.target.value)} 
                    required 
                  />
                </div>
                <div className="mb-3">
                  <label>Confirm New Password</label>
                  <input 
                    type="password" 
                    className="form-control" 
                    value={confirmPassword} 
                    onChange={(e) => setConfirmPassword(e.target.value)} 
                    required 
                  />
                </div>
                <button type="submit" className="btn btn-warning w-100 fw-bold">
                  Update Password
                </button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default ChangePassword;