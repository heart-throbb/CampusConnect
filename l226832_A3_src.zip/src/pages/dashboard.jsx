import React from 'react';
import { useSelector } from 'react-redux';
import { Link } from 'react-router-dom';

function Dashboard() {
  const currentUser = useSelector((state) => state.user.currentUser);

  return (
    <div className="container mt-5 mb-5">
      <div className="row text-center mb-4">
        <div className="col-12">
          <h2>Campus Rideshare Dashboard</h2>
          {/* Conditional greeting based on auth state */}
          {currentUser ? (
            <p className="lead text-primary">Welcome back, {currentUser.name}!</p>
          ) : (
            <p className="lead text-muted">Please login to manage your rides.</p>
          )}
        </div>
      </div>

      <div className="row">
        <div className="col-md-4 mb-3">
          <div className="card shadow-sm text-center h-100 border-primary">
            <div className="card-body d-flex flex-column">
              <h5 className="card-title mt-2">Looking for a ride?</h5>
              <p className="card-text mb-4">
                Browse available rides and book a seat to your destination.
              </p>
              <Link to="/rides" className="btn btn-outline-primary mt-auto fw-bold">
                Find a Ride
              </Link>
            </div>
          </div>
        </div>

        <div className="col-md-4 mb-3">
          <div className="card shadow-sm text-center h-100 border-success">
            <div className="card-body d-flex flex-column">
              <h5 className="card-title mt-2">Driving to campus?</h5>
              <p className="card-text mb-4">
                Have empty seats? Post a ride and help out your fellow students.
              </p>
              <Link to="/post-ride" className="btn btn-success mt-auto fw-bold">
                Offer a Ride
              </Link>
            </div>
          </div>
        </div>

        <div className="col-md-4 mb-3">
          <div className="card shadow-sm text-center h-100 border-warning">
            <div className="card-body d-flex flex-column">
              <h5 className="card-title mt-2">Your Reservations</h5>
              <p className="card-text mb-4">
                View the details of the rides you have already booked.
              </p>
              <Link to="/my-bookings" className="btn btn-warning mt-auto fw-bold">
                My Bookings
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Dashboard;