import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { bookSingleRide } from '../redux/rideSlice';
import { Link } from 'react-router-dom';

function AllRides() {
  const rides = useSelector((state) => state.rides.allRides);
  const isLoggedIn = useSelector((state) => state.user.isLoggedIn);
  const dispatch = useDispatch();

  const handleBooking = (rideId) => {
    // Auth guard: logic requires an active session to dispatch booking
    if (!isLoggedIn) {
      alert("Please login first to book a ride!");
      return;
    }
    dispatch(bookSingleRide({ rideId }));
  };

  return (
    <div className="container mt-4 mb-5">
      <h2 className="mb-4">Available Campus Rides</h2>

      {/* Render fallback UI if no rides are returned from the store */}
      {rides.length === 0 ? (
        <div className="alert alert-info">
          No rides available right now. 
          <Link to="/post-ride" className="alert-link">Be the first to post one!</Link>
        </div>
      ) : (
        <div className="row">
          {rides.map((ride) => (
            <div key={ride.id} className="col-md-4 mb-3">
              <div className="card shadow-sm h-100">
                <div className="card-body">
                  <h5 className="card-title text-primary">
                    {ride.pickupLocation} ➔ {ride.destination}
                  </h5>
                  
                  <p className="card-text mb-1">
                    <strong>Driver:</strong> 
                    <Link to={`/profile/${ride.driverName}`}>{ride.driverName}</Link>
                  </p>
                  <p className="card-text mb-1"><strong>Time:</strong> {ride.departureTime}</p>
                  <p className="card-text mb-3 text-success"><strong>Seats Left:</strong> {ride.seats}</p>
                  
                  <button
                    className="btn btn-success w-100 mt-auto"
                    onClick={() => handleBooking(ride.id)}
                    disabled={ride.seats === 0}
                  >
                    {ride.seats === 0 ? "Ride Full" : "Book Seat"}
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export default AllRides;