import React from 'react';
import { useSelector } from 'react-redux';
import { Link } from 'react-router-dom';

function MyBookings() {
  const isLoggedIn = useSelector((state) => state.user.isLoggedIn);
  const myRides = useSelector((state) => state.rides.myBookedRides);

  // Auth guard: prevent unauthenticated access to personal bookings
  if (!isLoggedIn) {
    return (
      <div className="container mt-5 text-center">
        <h3 className="text-danger">Access Denied</h3>
        <p>You must be logged in to view your bookings.</p>
        <Link to="/login" className="btn btn-primary">Go to Login</Link>
      </div>
    );
  }

  return (
    <div className="container mt-4">
      <h2 className="mb-4">My Booked Rides</h2>

      {/* Render empty state fallback if no bookings exist */}
      {myRides.length === 0 ? (
        <div className="alert alert-info">
          You haven't booked any rides yet. 
          <Link to="/rides" className="alert-link">Find a ride here!</Link>
        </div>
      ) : (
        <div className="row">
          {myRides.map((ride, index) => (
            <div key={index} className="col-md-4 mb-3">
              <div className="card shadow-sm border-success">
                <div className="card-header bg-success text-white">
                  Booking Confirmed
                </div>
                <div className="card-body">
                  <h5 className="card-title">
                    {ride.pickupLocation} ➔ {ride.destination}
                  </h5>
                  <p className="card-text mb-1"><strong>Driver:</strong> {ride.driverName}</p>
                  <p className="card-text mb-1"><strong>Time:</strong> {ride.departureTime}</p>
                  <p className="card-text mb-1"><strong>Vehicle:</strong> {ride.vehicleType}</p>
                  <hr />
                  <p className="card-text mb-0 text-muted">
                    <strong>Contact:</strong> {ride.contactInfo}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export default MyBookings;