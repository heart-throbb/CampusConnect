import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { useSelector } from 'react-redux';

function UserProfile() {
  const { driverName } = useParams();
  const allRides = useSelector((state) => state.rides.allRides);

  // Filter rides to find those specifically associated with the URL parameter
  const driverRides = allRides.filter((ride) => ride.driverName === driverName);

  if (driverRides.length === 0) {
    return (
      <div className="container mt-5 text-center">
        <h3>User not found</h3>
        <p>This user hasn't posted any active rides.</p>
        <Link to="/rides" className="btn btn-primary">Back to Rides</Link>
      </div>
    );
  }

  // Derive driver metadata from the first available ride record
  const driverContact = driverRides[0].contactInfo;

  return (
    <div className="container mt-4 mb-5">
      <div className="row">
        <div className="col-md-4 mb-4">
          <div className="card shadow-sm border-primary">
            <div className="card-header bg-primary text-white text-center">
              <h4>Driver Profile</h4>
            </div>
            <div className="card-body text-center">
              <div className="mb-3">
                <span className="display-1">👤</span>
              </div>
              <h3 className="card-title">{driverName}</h3>
              <hr />
              <p className="card-text text-muted">
                <strong>Contact:</strong> {driverContact}
              </p>
              <span className="badge bg-success">Verified Campus Driver</span>
            </div>
          </div>
        </div>

        <div className="col-md-8">
          <h3 className="mb-3">Rides Offered by {driverName}</h3>
          
          <div className="row">
            {driverRides.map((ride) => (
              <div key={ride.id} className="col-12 mb-3">
                <div className="card shadow-sm">
                  <div className="card-body">
                    <h5 className="card-title text-primary">
                      {ride.pickupLocation} ➔ {ride.destination}
                    </h5>
                    <p className="card-text mb-1"><strong>Time:</strong> {ride.departureTime}</p>
                    <p className="card-text mb-1"><strong>Vehicle:</strong> {ride.vehicleType}</p>
                    <p className="card-text"><strong>Seats Available:</strong> {ride.seats}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

export default UserProfile;