import React, { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { createNewRide } from '../redux/rideSlice';

function PostRide() {
  const [driverName, setDriverName] = useState('');
  const [pickupLocation, setPickupLocation] = useState('');
  const [destination, setDestination] = useState('');
  const [departureTime, setDepartureTime] = useState('');
  const [seats, setSeats] = useState('');
  const [vehicleType, setVehicleType] = useState('');
  const [contactInfo, setContactInfo] = useState('');

  const dispatch = useDispatch();
  const navigate = useNavigate();
  const isLoggedIn = useSelector((state) => state.user.isLoggedIn);

  const handleSubmit = (e) => {
    e.preventDefault();

    // Prevent submission if user session is invalid
    if (!isLoggedIn) {
      alert("You must be logged in to post a ride!");
      navigate('/login');
      return;
    }

    const newRideData = {
      driverName,
      pickupLocation,
      destination,
      departureTime,
      seats: Number(seats), // Ensure seats are dispatched as an integer
      vehicleType,
      contactInfo,
    };

    dispatch(createNewRide(newRideData));
    alert("Ride posted successfully!");
    navigate('/rides');
  };

  return (
    <div className="container mt-4 mb-5">
      <div className="row justify-content-center">
        <div className="col-md-8">
          <div className="card shadow-sm">
            <div className="card-body">
              <h3 className="card-title text-center mb-4">Offer a Ride</h3>
              
              <form onSubmit={handleSubmit}>
                <div className="row">
                  <div className="col-md-6 mb-3">
                    <label>Driver Name</label>
                    <input 
                      type="text" 
                      className="form-control" 
                      value={driverName} 
                      onChange={(e) => setDriverName(e.target.value)} 
                      required 
                    />
                  </div>
                  <div className="col-md-6 mb-3">
                    <label>Contact Info (Phone/Email)</label>
                    <input 
                      type="text" 
                      className="form-control" 
                      value={contactInfo} 
                      onChange={(e) => setContactInfo(e.target.value)} 
                      required 
                    />
                  </div>
                </div>

                <div className="row">
                  <div className="col-md-6 mb-3">
                    <label>Pickup Location</label>
                    <input 
                      type="text" 
                      className="form-control" 
                      placeholder="e.g., Baghbanpura" 
                      value={pickupLocation} 
                      onChange={(e) => setPickupLocation(e.target.value)} 
                      required 
                    />
                  </div>
                  <div className="col-md-6 mb-3">
                    <label>Destination</label>
                    <input 
                      type="text" 
                      className="form-control" 
                      placeholder="e.g., Askari 10" 
                      value={destination} 
                      onChange={(e) => setDestination(e.target.value)} 
                      required 
                    />
                  </div>
                </div>

                <div className="row">
                  <div className="col-md-4 mb-3">
                    <label>Departure Time</label>
                    <input 
                      type="time" 
                      className="form-control" 
                      value={departureTime} 
                      onChange={(e) => setDepartureTime(e.target.value)} 
                      required 
                    />
                  </div>
                  <div className="col-md-4 mb-3">
                    <label>Available Seats</label>
                    <input 
                      type="number" 
                      min="1" 
                      max="10" 
                      className="form-control" 
                      value={seats} 
                      onChange={(e) => setSeats(e.target.value)} 
                      required 
                    />
                  </div>
                  <div className="col-md-4 mb-3">
                    <label>Vehicle Type</label>
                    <input 
                      type="text" 
                      className="form-control" 
                      placeholder="e.g., Honda Civic" 
                      value={vehicleType} 
                      onChange={(e) => setVehicleType(e.target.value)} 
                      required 
                    />
                  </div>
                </div>

                <button type="submit" className="btn btn-primary w-100 mt-3">
                  Post Ride
                </button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default PostRide;