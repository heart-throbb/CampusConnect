import { createSlice } from '@reduxjs/toolkit';

const userSlice = createSlice({
  name: 'user',
  initialState: {
    currentUser: null,
    isLoggedIn: false,
    usersList: [] 
  },
  reducers: {
    registerUser: (state, action) => {
      state.usersList.push(action.payload);
    },
    loginUser: (state, action) => {
      const { email, password } = action.payload;
      const foundUser = state.usersList.find(
        (user) => user.email === email && user.password === password
      );

      if (foundUser) {
        state.currentUser = foundUser;
        state.isLoggedIn = true;
      } else {
        alert("Wrong email or password. Please try again.");
      }
    },
    logoutUser: (state) => {
      state.currentUser = null;
      state.isLoggedIn = false;
    },
    changePasswordUser: (state, action) => {
      if (state.currentUser) {
        const newPassword = action.payload;
        
        // Update both session state and persistence list
        state.currentUser.password = newPassword;
        
        const userIndex = state.usersList.findIndex(
          (u) => u.email === state.currentUser.email
        );
        
        if (userIndex !== -1) {
          state.usersList[userIndex].password = newPassword;
        }
      }
    }
  }
});

export const { 
  registerUser, 
  loginUser, 
  logoutUser, 
  changePasswordUser 
} = userSlice.actions;

export default userSlice.reducer;