import { createSlice } from '@reduxjs/toolkit';

const rideSlice = createSlice({
  name: 'rides',
  initialState: {
    allRides: [],
    myBookedRides: [],
  },
  reducers: {
    createNewRide: (state, action) => {
      const newRide = { ...action.payload, id: Math.random() };
      state.allRides.push(newRide);
    },
    bookSingleRide: (state, action) => {
      const rideToBook = state.allRides.find((ride) => ride.id === action.payload.rideId);

      // Validate availability before updating seat count and user bookings
      if (rideToBook && rideToBook.seats > 0) {
        rideToBook.seats -= 1;
        state.myBookedRides.push(rideToBook);
        alert("Ride booked successfully!");
      } else {
        alert("Sorry, no seats left on this ride!");
      }
    }
  }
});

export const { createNewRide, bookSingleRide } = rideSlice.actions;
export default rideSlice.reducer;