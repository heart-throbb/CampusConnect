import React from 'react';
import { BrowserRouter, Routes, Route, Link } from 'react-router-dom';
import AllRides from './pages/allRides';
import Login from './pages/login';
import Register from './pages/register';
import PostRide from './pages/PostRide';
import MyBookings from './pages/MyBookings';
import ChangePassword from './pages/ChangePassword';
import UserProfile from './pages/UserProfile';
import Dashboard from './pages/dashboard';

function App() {
  return (
    <BrowserRouter>
      <nav className="navbar navbar-expand-lg navbar-light bg-light mb-4 px-3">
        <Link className="navbar-brand" to="/">Campus Rides</Link>
        <div className="navbar-nav">
          <Link className="nav-item nav-link" to="/rides">Find a Ride</Link>
          <Link className="nav-item nav-link" to="/login">Login</Link>
          <Link className="nav-item nav-link" to="/register">Register</Link>
          <Link className="nav-item nav-link" to="/post-ride">Offer a Ride</Link>
          <Link className="nav-item nav-link" to="/my-bookings">My Bookings</Link>
          <Link className="nav-item nav-link" to="/change-password">Settings</Link>
        </div>
      </nav>

      <Routes>
        <Route path="/" element={<Dashboard />} />
        <Route path="/rides" element={<AllRides />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/post-ride" element={<PostRide />} />
        <Route path="/my-bookings" element={<MyBookings />} />
        <Route path="/change-password" element={<ChangePassword />} />
        <Route path="/profile/:driverName" element={<UserProfile />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;